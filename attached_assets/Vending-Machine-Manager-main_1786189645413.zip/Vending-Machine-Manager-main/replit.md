# Discord 自販機 Bot

Discord内で複数の自販機を運営できるBotです。自販機ごとに商品・価格・配布内容・在庫方式を分け、管理者はドロップダウン選択中心の管理パネルから編集できます。

## Run & Operate

- `python main.py` — Discord Botとヘルスチェックサーバーを起動
- `python -m py_compile main.py database.py` — Python構文チェック
- `pnpm run typecheck` — ワークスペース側のTypeScriptチェック
- Required secret: `DISCORD_BOT_TOKEN` — Discord Botトークン（コードへ書かない）

## Stack

- Python 3.11, discord.py 2.x, Flask 3.x
- 保存: `vending_data.json`（原子的書き込み・自動マイグレーション）
- Discord: スラッシュコマンド、永続View、ドロップダウン選択、エフェメラル管理UI

## Where things live

- `main.py` — Discordイベント、購入フロー、管理UI、自販機パネル
- `database.py` — 商品・自販機・注文・在庫の保存とマイグレーション
- `requirements.txt` — Python依存関係
- `.replit` — `Discord Vending Bot`ワークフロー

## Architecture decisions

- 商品は `machine_name` で自販機単位に分離する。
- 有限在庫は配布内容の1行を1個として消費する。
- 無限在庫は配布内容1行をテンプレートとして繰り返し配布し、在庫表示は「無限」にする。
- 商品変更後は保存した自販機パネルを自動更新する。
- 有料商品だけPayPayリンクを要求し、無料商品は購入後に自動DMする。

## Product

- 管理者: `/vending`から自販機の作成・移動・更新、商品追加・編集・削除、配布内容の確認・削除、通知チャンネル選択
- 購入者: 自販機ごとの商品選択、在庫確認、無料商品の即時受取、有料商品のPayPay注文
- 配布内容は管理UIの商品設定でのみ表示し、購入者向け自販機パネルには表示しない

## User preferences

- Botトークンは`DISCORD_BOT_TOKEN` Secretを使い、ソースコードやチャットへ表示しない。
- 管理操作は可能な限りテキスト入力ではなく選択式にする。

## Gotchas

- Discord側でBotに対象チャンネルの表示・送信・メッセージ管理・DM送信に必要な権限を付与する。
- Discordのドロップダウンは1画面最大25件のため、商品・自販機・チャンネルが25件を超える場合はページ分割が必要。
- 無限在庫商品は配布内容を1行だけ持ち、その内容を購入個数分繰り返す。

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
