---
name: Python dependency environment
description: The Bot needs the managed Python tools runtime rather than the base Python module.
---

The managed `python-3.11` environment is required for installing and running the Discord Bot dependencies. The base Python module is externally managed and rejects pip installs.

**Why:** Replit's base Python environment does not expose a writable pip environment, while the Python tools module provides the workspace `.pythonlibs` location used by the workflow.

**How to apply:** Keep the project on the Python tools runtime and install dependencies from `requirements.txt` through the package-management flow before restarting the Bot workflow.